import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Supported locales for DAWEC. Arabic is RTL and drives
/// `Directionality` automatically via `MaterialApp.locale`.
const supportedLocales = [
  Locale('en'),
  Locale('ar'),
];

/// Holds the app's current [Locale].
///
/// Persistence (reading/writing [StorageKeys.locale]) will be added once a
/// local storage package is wired in — for now this defaults to English and
/// lives purely in memory.
class LocaleNotifier extends Notifier<Locale> {
  @override
  Locale build() => const Locale('en');

  void setLocale(Locale locale) {
    if (supportedLocales.contains(locale)) {
      state = locale;
    }
  }

  void toggle() {
    state = state.languageCode == 'en' ? const Locale('ar') : const Locale('en');
  }
}

final localeProvider = NotifierProvider<LocaleNotifier, Locale>(
  LocaleNotifier.new,
);
