import 'package:flutter/material.dart';

import '../../../../shared/widgets/module_placeholder.dart';

/// Placeholder screen for the Stations module.
///
/// Wired into the app shell via app/router.dart's StatefulShellRoute.
/// Business logic (data/domain/presentation) for this feature is
/// implemented in a later milestone.
class StationsScreen extends StatelessWidget {
  const StationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholder(moduleName: 'Stations');
  }
}
