import 'package:flutter/material.dart';

import '../../../../shared/widgets/module_placeholder.dart';

/// Placeholder screen for the Maintenance module.
///
/// Wired into the app shell via app/router.dart's StatefulShellRoute.
/// Business logic (data/domain/presentation) for this feature is
/// implemented in a later milestone.
class MaintenanceScreen extends StatelessWidget {
  const MaintenanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholder(moduleName: 'Maintenance');
  }
}
