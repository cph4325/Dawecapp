import 'package:flutter/material.dart';

import '../../../../shared/widgets/module_placeholder.dart';

/// Placeholder screen for the Inventory module.
///
/// Wired into the app shell via app/router.dart's StatefulShellRoute.
/// Business logic (data/domain/presentation) for this feature is
/// implemented in a later milestone.
class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholder(moduleName: 'Inventory');
  }
}
