/// Contract every feature's data model should implement so repositories can
/// treat serialization uniformly once API integration begins.
abstract class BaseModel {
  Map<String, dynamic> toJson();
}
