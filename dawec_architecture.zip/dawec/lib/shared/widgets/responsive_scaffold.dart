import 'package:flutter/material.dart';

import '../../core/utils/responsive.dart';

/// A scaffold that swaps between a bottom nav bar (mobile) and a nav rail
/// (tablet/desktop) — the shared shell used by [app/router.dart]'s
/// `StatefulShellRoute`.
class ResponsiveScaffold extends StatelessWidget {
  const ResponsiveScaffold({
    super.key,
    required this.body,
    required this.destinations,
    required this.selectedIndex,
    required this.onDestinationSelected,
    this.title,
  });

  final Widget body;
  final List<NavigationDestination> destinations;
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final Widget? title;

  @override
  Widget build(BuildContext context) {
    final isWide = !Responsive.isMobile(context);

    if (isWide) {
      return Scaffold(
        appBar: title != null ? AppBar(title: title) : null,
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              labelType: NavigationRailLabelType.all,
              destinations: destinations
                  .map((d) => NavigationRailDestination(
                        icon: d.icon,
                        selectedIcon: d.selectedIcon,
                        label: Text(d.label),
                      ))
                  .toList(),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: body),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: title != null ? AppBar(title: title) : null,
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: onDestinationSelected,
        destinations: destinations,
      ),
    );
  }
}
