import 'package:flutter/material.dart';

/// Placeholder body for feature screens whose business logic hasn't been
/// implemented yet. Keeps `router.dart` wireable end-to-end today.
class ModulePlaceholder extends StatelessWidget {
  const ModulePlaceholder({super.key, required this.moduleName});

  final String moduleName;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.construction_outlined, size: 40, color: theme.colorScheme.outline),
          const SizedBox(height: 12),
          Text(moduleName, style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            'This module is under construction.',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.outline),
          ),
        ],
      ),
    );
  }
}
