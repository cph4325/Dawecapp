/// Build/runtime environment for DAWEC.
///
/// Wiring to actual environment variables / --dart-define values will be
/// added once API integration begins.
enum Env { dev, staging, prod }

const Env kCurrentEnv = Env.dev;
