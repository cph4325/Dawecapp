import 'env.dart';

/// Static, non-secret app configuration.
///
/// This is intentionally free of any API base URLs / keys for now —
/// network integration is a later milestone. See [Env] for the active
/// build environment.
class AppConfig {
  AppConfig._();

  static const String appName = 'DAWEC';
  static const Env environment = kCurrentEnv;

  /// Default breakpoints used by [core/utils/responsive.dart].
  static const double mobileBreakpoint = 600;
  static const double tabletBreakpoint = 1024;
  static const double desktopBreakpoint = 1440;
}
