/// Shared form-field validators. Return `null` when valid, an error
/// message otherwise — matching Flutter's `FormField.validator` contract.
class Validators {
  Validators._();

  static String? required(String? value, {String message = 'Required'}) {
    if (value == null || value.trim().isEmpty) return message;
    return null;
  }

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    final regex = RegExp(r'^[\w\.\-]+@([\w\-]+\.)+[\w\-]{2,}$');
    if (!regex.hasMatch(value.trim())) return 'Invalid email address';
    return null;
  }

  static String? minLength(String? value, int length) {
    if (value == null || value.length < length) {
      return 'Must be at least $length characters';
    }
    return null;
  }
}
