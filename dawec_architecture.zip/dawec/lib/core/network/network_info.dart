/// Abstraction over device connectivity checks.
///
/// Left unimplemented deliberately — this task only lays out architecture.
/// A real implementation (e.g. backed by `connectivity_plus`) will be added
/// alongside API integration.
abstract class NetworkInfo {
  Future<bool> get isConnected;
}

/// Placeholder implementation so the app compiles before connectivity
/// checking is wired up. Always reports connected.
class NetworkInfoImpl implements NetworkInfo {
  const NetworkInfoImpl();

  @override
  Future<bool> get isConnected async => true;
}
