/// Exceptions thrown from the `data` layer (datasources/repositories).
///
/// These get caught and translated into [Failure]s before reaching the
/// `domain`/`presentation` layers. No network implementation exists yet —
/// these are declared so the error-handling contract is in place from day one.
class ServerException implements Exception {
  final String message;
  const ServerException([this.message = 'Server error']);
}

class CacheException implements Exception {
  final String message;
  const CacheException([this.message = 'Cache error']);
}

class NetworkException implements Exception {
  final String message;
  const NetworkException([this.message = 'No network connection']);
}

class UnauthorizedException implements Exception {
  final String message;
  const UnauthorizedException([this.message = 'Unauthorized']);
}

class ValidationException implements Exception {
  final String message;
  const ValidationException([this.message = 'Validation error']);
}
