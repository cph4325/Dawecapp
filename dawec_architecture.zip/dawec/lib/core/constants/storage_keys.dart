/// Keys used for local persistence (theme mode, locale, auth token, etc.).
///
/// The actual storage backend (shared_preferences / secure storage) will be
/// wired up when persistence is implemented; this file just centralizes the
/// keys so features don't hardcode strings.
class StorageKeys {
  StorageKeys._();

  static const String themeMode = 'dawec.theme_mode';
  static const String locale = 'dawec.locale';
  static const String authToken = 'dawec.auth_token';
  static const String onboardingComplete = 'dawec.onboarding_complete';
}
