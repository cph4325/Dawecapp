/// Non-visual constants shared across the app.
class AppConstants {
  AppConstants._();

  static const Duration snackBarDuration = Duration(seconds: 3);
  static const Duration debounceDuration = Duration(milliseconds: 400);
  static const Duration splashMinDuration = Duration(milliseconds: 600);
}

/// Standard spacing scale, use instead of magic numbers in `EdgeInsets`/`SizedBox`.
class AppSpacing {
  AppSpacing._();

  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

/// Standard corner radii.
class AppRadius {
  AppRadius._();

  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double pill = 999;
}
