import 'package:logger/logger.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Thin wrapper around `package:logger` so call sites depend on our own
/// abstraction rather than the third-party API directly.
class LoggerService {
  LoggerService() : _logger = Logger(printer: PrettyPrinter(methodCount: 1));

  final Logger _logger;

  void debug(String message) => _logger.d(message);
  void info(String message) => _logger.i(message);
  void warning(String message) => _logger.w(message);
  void error(String message, [Object? error, StackTrace? stackTrace]) =>
      _logger.e(message, error: error, stackTrace: stackTrace);
}

final loggerServiceProvider = Provider<LoggerService>((ref) {
  return LoggerService();
});
