# DAWEC — Project Architecture

Enterprise Flutter application scaffold. This commit establishes **architecture
only** — no business logic, no API calls.

## Stack

| Concern              | Choice                                   |
|-----------------------|-------------------------------------------|
| State management      | `flutter_riverpod` (Notifier API)         |
| Routing                | `go_router` (`StatefulShellRoute.indexedStack`) |
| Design system          | Material 3, seeded ColorScheme, light + dark |
| Localization            | English + Arabic (auto RTL), `intl` + ARB files |
| Responsive layout        | Bottom nav (mobile) / Nav rail (tablet+desktop) |
| Architecture pattern       | Clean-ish layering: `data` / `domain` / `presentation` per feature |

## Folder structure

```
lib/
├── app/            # App shell: MaterialApp.router, theme, GoRouter, locale/theme providers
├── core/           # Cross-cutting: constants, errors, network, utils, services, widgets
├── config/         # Static app config + build environment
├── shared/         # Reusable models/widgets/extensions used by 2+ features
└── features/
    ├── auth/
    ├── dashboard/
    ├── stations/
    ├── laboratory/
    ├── ro/
    ├── maintenance/
    ├── inventory/
    ├── reports/
    ├── notifications/
    └── settings/
        ├── data/           # datasources, models, repository implementations
        ├── domain/         # entities, repository contracts, usecases
        └── presentation/   # screens, widgets, riverpod providers
```

Every feature screen currently renders a `ModulePlaceholder` — routes and
navigation are fully wired, but no feature has business logic yet.

## Getting the project running

This scaffold was authored outside a machine with the Flutter SDK installed,
so it has **not** been run through `flutter pub get` / `flutter analyze`
here. To bring it up locally:

```bash
# 1. Generate missing platform folders (android/, ios/, web/, etc.) —
#    this scaffold ships lib/ + pubspec.yaml only.
flutter create --org com.dawec --project-name dawec .

# 2. Fetch dependencies
flutter pub get

# 3. Generate localization classes from lib/l10n/*.arb
flutter gen-l10n

# 4. Uncomment the AppLocalizations delegate + supportedLocales wiring
#    in lib/app/app.dart once step 3 has generated
#    lib/l10n/generated/app_localizations.dart

# 5. Run
flutter run
```

> **Note:** `flutter create .` will not overwrite the existing `lib/` or
> `pubspec.yaml` — it only fills in the platform scaffolding (`android/`,
> `ios/`, `web/`, `linux/`, `macos/`, `windows/`) that a from-scratch `flutter
> create` normally generates. Merge its `pubspec.yaml` platform fields if
> prompted.

## What's intentionally stubbed

- `core/network/network_info.dart` — connectivity check contract, no HTTP client wired.
- `core/errors/` — `Exception` → `Failure` contract, ready for repositories to use.
- Every `features/*/data`, `domain` folder — empty, awaiting the first real feature.
- `app/app.dart` — `AppLocalizations.delegate` commented out until `flutter gen-l10n` runs.

## Next steps (not part of this task)

- Implement auth feature end-to-end as the reference pattern for the rest.
- Wire an HTTP client (Dio) behind `core/network`.
- Add persistence for theme/locale (`shared_preferences`) in the two providers under `lib/app/providers/`.
